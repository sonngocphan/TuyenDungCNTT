﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TuyenDungCNTT.Models.ViewModels.Employer
{
    public class EmployerEdit
    {
        public int MaNTD { get; set; }

        public string TenNTD { get; set; }

        public string TenNDD { get; set; }

        public string ChucVuNDD { get; set; }

        public string SoDienThoai { get; set; }

        public string QuyMo { get; set; }

        public string MoTa { get; set; }

        public string DiaChi { get; set; }

        public string Website { get; set; }
    }
}