﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TuyenDungCNTT.Models.ViewModels.HoSoXinViec
{
    public class HoSoXinViecSearch
    {
        public string CapBac { get; set; }
        public string ChuyenNganh { get; set; }
        public string LoaiCV { get; set; }
    }
}