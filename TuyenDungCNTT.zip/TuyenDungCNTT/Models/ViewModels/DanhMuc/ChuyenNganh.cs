﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TuyenDungCNTT.Models.ViewModels.DanhMuc
{
    public class ChuyenNganh
    {
        public string MaCN { get; set; }

        public string TenCN { get; set; }
    }
}