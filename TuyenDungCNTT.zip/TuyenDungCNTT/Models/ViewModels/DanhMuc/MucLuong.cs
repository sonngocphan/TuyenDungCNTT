﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TuyenDungCNTT.Models.ViewModels.DanhMuc
{
    public class MucLuong
    {
        public string MaMucLuong { get; set; }

        public string TenMucLuong { get; set; }
    }
}