﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TuyenDungCNTT.Models.ViewModels.DanhMuc
{
    public class LoaiCongViec
    {
        public string MaLoaiCV { get; set; }

        public string TenLoaiCV { get; set; }
    }
}