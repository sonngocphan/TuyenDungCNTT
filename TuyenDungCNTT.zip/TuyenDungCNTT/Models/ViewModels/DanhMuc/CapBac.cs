﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TuyenDungCNTT.Models.ViewModels.DanhMuc
{
    public class CapBac
    {
        public string MaCapBac { get; set; }

        public string TenCapBac { get; set; }
    }
}