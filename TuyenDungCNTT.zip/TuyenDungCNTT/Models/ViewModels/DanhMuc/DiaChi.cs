﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TuyenDungCNTT.Models.ViewModels.DanhMuc
{
    public class DiaChi
    {
        public string MaDiaChi { get; set; }

        public string TenDiaChi { get; set; }
    }
}