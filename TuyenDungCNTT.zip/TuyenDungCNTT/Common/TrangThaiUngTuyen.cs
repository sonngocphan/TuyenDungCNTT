﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TuyenDungCNTT.Common
{
    public class TrangThaiUngTuyen
    {
        public static string DALUU = "Đã lưu";
        public static string CHUAXEM = "Chưa xem";
        public static string DAXEM = "Đã xem";
        public static string TUCHOI = "Từ chối";
        public static string CHAPNHAN = "Được nhận";
        public static string TIEMNANG = "Ứng viên tiềm năng";
        public static string HENPHONGVAN = "Hẹn phỏng vấn";
    }
}